package net.codejava;

public enum Role {
	ADMIN, USER
}
